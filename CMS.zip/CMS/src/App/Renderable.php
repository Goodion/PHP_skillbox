<?php

namespace src\App;

interface Renderable
{
    public function render();
}