<?php

namespace src\App;

class Controller
{
    public static function index()
    {
        return 'home';
    }

    public static function about()
    {
        return 'about';
    }
}
